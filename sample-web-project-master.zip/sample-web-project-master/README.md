# sample-web-project
Sample web project used to showcase a deployment process with Flightplan.js and git

The full article is available at http://usersnap.com/blog/deploying-static-websites-flightplan/
